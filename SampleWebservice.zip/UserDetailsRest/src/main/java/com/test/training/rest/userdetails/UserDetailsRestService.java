package com.test.training.rest.userdetails;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;


@Path("/userdetails")
public interface UserDetailsRestService {

	@GET
	@Path("/address/{id}")
	@Produces("application/json")
	public String getAddressDetails(@PathParam("id") String id );

	@PUT
	@Path("/putaddress")
	@Produces("application/json")
	public String putAddressDetails(String body );
}
