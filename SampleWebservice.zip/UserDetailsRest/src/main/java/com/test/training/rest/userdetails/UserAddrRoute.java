package com.test.training.rest.userdetails;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.model.dataformat.XmlJsonDataFormat;

public class UserAddrRoute extends RouteBuilder{

	public static Map<String, String> xmlJsonOptions = new HashMap<String, String>();
	
	
	@Override
	public void configure() throws Exception {

			xmlJsonOptions.put(XmlJsonDataFormat.SKIP_NAMESPACES, "true");
			
		from("cxfrs:bean:rsUserDetails?bindingStyle=SimpleConsumer")
			.log("Requested User Address details for id : ${header.id}")
			.choice()
				.when(header("operationName").isEqualTo("getAddressDetails"))
					.setHeader("name",simple("${properties:${header.id}:100}"))
					.setBody().constant("<xml/>")
					.to("xslt:template/getAddress.xsl")
					.removeHeaders("CamelHttp*")
					.setHeader(CxfConstants.OPERATION_NAME).constant("getUserAddressDetails")
					.setHeader(CxfConstants.OPERATION_NAMESPACE).constant("http://com.test.training/useraddress")
					.to("cxf:bean:addressEndpoint")
					.marshal().xmljson(xmlJsonOptions).endChoice()
				.when(header("operationName").isEqualTo("putAddressDetails"))
					.setHeader("name").jsonpath("$.name", true)
					.setHeader("city").jsonpath("$.city",true)
					.setHeader("street").jsonpath("$.street", true)
					.setBody().constant("<xml/>")
					.to("xslt:template/putAddress.xsl")
					.removeHeaders("CamelHttp*")
					.setHeader(CxfConstants.OPERATION_NAME).constant("putUserAddressDetails")
					.setHeader(CxfConstants.OPERATION_NAMESPACE).constant("http://com.test.training/useraddress")
					.to("cxf:bean:addressEndpoint")
					.marshal().xmljson(xmlJsonOptions).endChoice()
		.end();
	}

	
}
