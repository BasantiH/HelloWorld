package com.test.training.userdetails;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;

@WebService(name="UserDetails",targetNamespace="http://com.test.training/userdetails")
public interface UserDetailsService {

	@WebMethod(operationName="getUserDetails",action="http://com.test.training/userdetails/getuserdetails")
	@RequestWrapper(className="com.test.training.userdetails.UserDetails" ,localName="GetUserDetails")
	public String getUserDetails( UserDetails body);
	
}
