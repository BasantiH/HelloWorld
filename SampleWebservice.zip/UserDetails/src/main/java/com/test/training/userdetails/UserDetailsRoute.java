package com.test.training.userdetails;

import org.apache.camel.builder.RouteBuilder;

public class UserDetailsRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {

		from("cxf:bean:userDetailsEndpoint")
			.log("the body content :: ${body}")
		.end();
		
	}

}
