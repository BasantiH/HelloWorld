package com.test.training.useraddress;

import org.apache.camel.builder.xml.Namespaces;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.log4j.Logger;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class UserAdressRoute extends RouteBuilder{

	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	@Override
	public void configure() throws Exception {
	
		Namespaces n1 = new Namespaces("addr", "http://com.test.training/useraddress");
		
		from("cxf:bean:userAddressEndpoint").streamCaching()
		.convertBodyTo(java.lang.String.class)
		.log("the input content : ${body}")
		.choice()
			.when().simple("${header.operationName} == 'putUserAddressDetails'")
				.setHeader("name").xpath("/addr:AddUserAddressRequest/name/text()",n1)
				.setHeader("street").xpath("/addr:AddUserAddressRequest/street/text()",n1)
				.setHeader("city").xpath("/addr:AddUserAddressRequest/city/text()",n1)
				.log("the user name : ${header.name} ,street : ${header.street} , city : ${header.city}")
				.to("xslt:template/putAddressResponse.xsl")
			.when().simple("${header.operationName} == 'getUserAddressDetails'")
				.setHeader("name").xpath("/addr:UserAddressRequest/name/text()",n1)
				.setHeader("address",simple("${properties:${header.name}:street,city}"))
				.setBody().constant("<xml/>")
				.to("xslt:template/getAddressResponse.xsl")
				.log("the out : ${body}")
		.end();
		
	}

}
