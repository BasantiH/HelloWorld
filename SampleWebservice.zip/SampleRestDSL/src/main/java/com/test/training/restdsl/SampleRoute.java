package com.test.training.restdsl;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;

public class SampleRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		
		restConfiguration().component("restlet").port(9091);
			rest("/expose")
			.get("/rest/{id}").produces("application/json")
				.to("direct:samplerest")
			.put("/putaddress").produces("application/json")
				.to("direct:putaddress");
		
		
		from("direct:samplerest")
			.log("Inside the Rest DSL sample")
			.removeHeaders("Camelhttp*")
			.toD("http://localhost:8181/cxf/test/userdetails/address/${header.id}?throwExceptionOnFailure=false&bridgeEndpoint=true")
		.end();
		
		from("direct:putaddress")
			.convertBodyTo(java.lang.String.class)
			.log("Inside the Rest DSL put sample : ${body}")
			.removeHeaders("Camelhttp*")
			.setHeader(Exchange.HTTP_METHOD,constant("PUT"))
			.toD("http://localhost:8181/cxf/test/userdetails/putaddress?throwExceptionOnFailure=false&bridgeEndpoint=true")
		.end();
	    
	}

	
	
}
